# Privacy Policy

FontSeek does not collect, store, or transmit any personal data. All processing happens locally in your browser.
